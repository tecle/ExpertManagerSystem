<!-- Main Section End -->
        </section>
    </div>

    <!-- LOADING SCRIPT -->
    <script>
    $(window).load(function(){
        $("#loading").fadeOut(function(){
            $(this).remove();
            $('body').removeAttr('style');
        });
    });
    </script>
     <!-- LOADING SCRIPT -->
</body>
</html>