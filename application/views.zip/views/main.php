﻿            <section>
                <header class="container_12 clearfix">
                    <div class="grid_12">
                        <h1>怡信咨询专家库系统</h1>
                    </div>
                </header>
                <section class="container_12 clearfix">
                    <section class="portlet grid_6 leading">
                    <a href="<?=$url['expert']?>"><div class="message info"> 
                    <h3>行业顾问</h3> 
                    <p> 
                    点击进入行业顾问首页
                    </p> 
                    </div></a> 
                    <a href="<?=$url['project']?>"><div class="message success"> 
                    <h3>项目</h3> 
                    <p> 
                    点击进入项目首页
                    </p> 
                    </div>
                    </a> 
                    <a href="<?=$url['guest']?>"><div class="message warning"> 
                    <h3>客户</h3> 
                    <p> 
                    点击进入客户首页
                    </p> 
                    </div>
                    </a> 
                    </section>
                </section>
            </section>
                    
                    
            
   
    
   
