 <section>
                <header class="container_12 clearfix">
                    <div class="grid_12">
                        <h1>Add Client</h1>
                    </div>
                </header>
                <section class="container_12 clearfix">
                    <div class="portlet grid_12">
                        <header>
                            <h2>Client Information</h2>
                        </header>
                        <section>
                            
                            <form class="form has-validation" id="form1" name="form1" method="POST" action="/CIFramework/index.php/guest/welcome/addclient" enctype="multipart/form-data">
                            <h2>Basic Information</h2>
                            <div class="clearfix">

                                    <label for="gname" class="form-label">Client <em>*</em><small></small></label>

                                    <div class="form-input"><input type="text" id="gname" name="gname" required="required" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gtype" class="form-label">Client type<em>*</em><small></small></label>

                                    <div class="form-input"><select id="gtype" name="gtype" >
                                    <option value="咨询">咨询</option>
                           	        <option value="私募基金">私募基金</option>
                                    <option value="公募基金">公募基金</option>
                                    <option value="对冲基金">对冲基金</option>
                                    <option value="企业">企业</option>
                                    </select></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="ghalfhour" class="form-label">Half-hour Policy<em>*</em><small></small></label>

                                    <div class="form-input"><select id="ghalfhour" name="ghalfhour" >
                                    <option value="Y">有</option>
                           	        <option value="N">无</option>
                                    </select></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gintroduction" class="form-label">Client Introduction <em></em><small></small></label>

                                    <div class="form-input form-textarea"><textarea id="gintroduction" name="gintroduction" rows="5"></textarea></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gremark" class="form-label">Remark <em></em><small></small></label>

                                    <div class="form-input form-textarea"><textarea id="gremark" name="gremark" rows="5"></textarea></div>

                            </div>
                            
                            <h2>Business Contact</h2>
                            
                            <div style="display: none">
                                  		<input type="text" name="gbcyear" id="gbcyear" />
                                        <input type="text" name="gbcmonth" id="gbcmonth" />
                                        <input type="text" name="gbcday" id="gbcday" />
                                        
                                        <script type="text/javascript">
                                        	function setGbcyear(){
                            					document.getElementById("gbcyear").value = document.getElementById("byear").value;
                            					//alert(document.getElementById("eyear").value);
                            				}
                            				
                            				function setGbcmonth(){
                            					document.getElementById("gbcmonth").value = document.getElementById("bmonth").value;
                            				//	alert(document.getElementById("emonth").value);
                            				}
                            				
                            				function setGbcday(){
                            					document.getElementById("gbcday").value = document.getElementById("bday").value;
                            				//	alert(document.getElementById("eday").value);
                            				}
                            				
                                        </script>
                            </div>
                            
                            <div class="clearfix">

                                    <label for="gbcname" class="form-label">Client Name <em>*</em><small></small></label>

                                    <div class="form-input"><input type="text" id="gbcname" name="gbcname" required="required" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="byear" class="form-label">Birthday<em></em><small id="rolenote"></small></label>

                                    
                                    <select class="dateselect" id="byear" name="byear">                                    
                                    </select>
                                    年

                                    <select class="dateselect" id="bmonth" name="bmonth">                                    
                                    </select>
                                    月
                                    <select class="dateselect" id="bday" name="bday">                                    
                                    </select>
                                    日
                                    
                                    <script type="text/javascript">
                            			yobj = document.getElementById("byear");
                            			mobj = document.getElementById("bmonth");
                            			dobj = document.getElementById("bday");
                            			initDate(yobj, mobj, dobj);  
                            			yobj.onchange = function(){resetDay(yobj, mobj, dobj); setGbcyear();}
                            			mobj.onchange = function(){resetDay(yobj, mobj, dobj); setGbcmonth();}
                            			dobj.onchange = function(){setGbcday();}
                                    </script>
                            

                            </div>
                            <p></p>
                            <div class="clearfix">

                                    <label for="gbcsex" class="form-label">Gender<em></em><small></small></label>

                                    <div class="form-input"><select id="gbcsex" name="gbcsex" >
                                    <option value="M">Male</option>
                           	        <option value="F">Female</option>
                                    </select></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gbcposition" class="form-label">Position <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="gbcposition" name="gbcposition" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gbclandphone" class="form-label">Landline <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="gbclandphone" name="gbclandphone" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gbccellphone" class="form-label">Mobile <em>*</em><small></small></label>

                                    <div class="form-input"><input type="text" id="gbccellphone" name="gbccellphone" required="required" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gbcemail" class="form-label">Email <em>*</em><small></small></label>

                                    <div class="form-input"><input type="email" id="gbcemail" name="gbcemail" required="required"/></div>

                            </div>
                            
                            <h2>Payment Contact</h2>
                            
                            <div style="display: none">
                                  		<input type="text" name="gpcyear" id="gpcyear" />
                                        <input type="text" name="gpcmonth" id="gpcmonth" />
                                        <input type="text" name="gpcday" id="gpcday" />
                                        
                                        <script type="text/javascript">
                                        	function setGpcyear(){
                            					document.getElementById("gpcyear").value = document.getElementById("pyear").value;
                            					//alert(document.getElementById("eyear").value);
                            				}
                            				
                            				function setGpcmonth(){
                            					document.getElementById("gpcmonth").value = document.getElementById("pmonth").value;
                            				//	alert(document.getElementById("emonth").value);
                            				}
                            				
                            				function setGpcday(){
                            					document.getElementById("gpcday").value = document.getElementById("pday").value;
                            				//	alert(document.getElementById("eday").value);
                            				}
                            				
                                        </script>
                            </div>
                            
                            <div class="clearfix">

                                    <label for="gpcname" class="form-label">Client Name <em>*</em><small></small></label>

                                    <div class="form-input"><input type="text" id="gpcname" name="gpcname"  /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="pyear" class="form-label">Birthday<em></em><small></small></label>

                                    
                                    <select class="dateselect" id="pyear" name="pyear">                                    
                                    </select>
                                    年

                                    <select class="dateselect" id="pmonth" name="pmonth">                                    
                                    </select>
                                    月
                                    <select class="dateselect" id="pday" name="pday">                                    
                                    </select>
                                    日
                                    
                                    <script type="text/javascript">
                            			pyobj = document.getElementById("pyear");
                            			pmobj = document.getElementById("pmonth");
                            			pdobj = document.getElementById("pday");
                            			initDate(pyobj, pmobj, pdobj);  
                            			pyobj.onchange = function(){resetDay(pyobj, pmobj, pdobj); setGpcyear();}
                            			pmobj.onchange = function(){resetDay(pyobj, pmobj, pdobj); setGpcmonth();}
                            			pdobj.onchange = function(){setGpcday();}
                                    </script>
                            

                            </div>
                            <p></p>
                            <div class="clearfix">

                                    <label for="gpcsex" class="form-label">Gender<em></em><small></small></label>

                                    <div class="form-input"><select id="gpcsex" name="gpcsex" >
                                    <option value="M">Male</option>
                           	        <option value="F">Female</option>
                                    </select></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gpcposition" class="form-label">Position <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="gpcposition" name="gpcposition" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gpclandphone" class="form-label">Landline <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="gpclandphone" name="gpclandphone" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gpccellphone" class="form-label">Mobile <em>*</em><small></small></label>

                                    <div class="form-input"><input type="text" id="gpccellphone" name="gpccellphone" required="required" /></div>

                            </div>
                            
                            <div class="clearfix">

                                    <label for="gpcemail" class="form-label">Email <em>*</em><small></small></label>

                                    <div class="form-input"><input type="email" id="gpcemail" name="gpcemail" required="required" /></div>

                            </div>                                                                  

                            
                            <div class="form-action clearfix">

                                        <button class="button"  onclick="validate()" data-icon-primary="ui-icon-circle-check">OK</button>

                            </div>
                         

                                

                            </form>
                        </section>
                    </div>
                </section>
            </section>

           
 