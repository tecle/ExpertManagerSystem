  <section>
                <header class="container_12 clearfix">
                    <div class="grid_12">
                        <h1>Add Consultant Required</h1>
                    </div>
                </header>
                <section class="container_12 clearfix">
                    <div class="portlet grid_12">
                        <header>
                            <h2>Consultant Required Information</h2>
                        </header>
                        <section>
                            <form class="form has-validation" id="form1" name="form1" enctype="multipart/form-data">
                                <div style="display: none">
                                	<input type="text" id="eid" name="eid" value='<?= $eid ?>'/>
                                    <input type="text" id="piid" name="piid" value='<?= $piid ?>'/>
                                    <input type="text" id="halfhour" name="halfhour" value='<?= $ghalfhour?>' />
                                </div>
                                <div class="clearfix">
                                    <label for="estatus" class="form-label">Status<em></em><small id="rolenote"></small></label>
                              	      <div class="form-input"><select name="estatus" id="estatus" onchange="statusChange()">
                              	        <option value="1">聘用</option>
                              	        <option value="2">合作</option>
                                        <option value="3">推荐</option>
                                        <option value="4">已预约</option>
                                        <option value="5">已访谈</option>
                                        <option value="6">已评分</option>
                                        <option value="7">已付款</option>
                                      </select></div>
                                </div>
                                <div class="clearfix">

                                    <label for="epicharge" class="form-label">PIC<em>*</em><small></small></label>

                                    <div class="form-input"><select id="epicharge" name="epicharge" onchange="statusChange()">
                                    </select></div>
                                        <script>//获取admin列表
                                        var sobj = document.getElementById("epicharge");
                                        var alist;
                                        getAdminList('type=6');
                                        function getAdminList(string){
                                        $.ajax({
                                                    type: 'post',
                                                    //可选get
                                                    url: '/CIFramework/index.php/project/welcome/projectAjax',
                                                    //这里是接收数据的PHP程序
                                                    data: string,
                                                    //传给PHP的数据，多个参数用&连接
                                                    dataType: 'text',
                                                    //服务器返回的数据类型 可选XML ,Json jsonp script html text等
                                                    success: function(msg) {
                                                           // return msg;
                                                            alist = msg;
                                                            epichargeInit();
                                                            //这里是ajax提交成功后，PHP程序返回的数据处理函数。msg是返回的数据，数据类型在dataType参数里定义！
                                                    },
                                                    error: function() {
                                                            alert("获取用户列表失败!");
                                                    }
                                            })
                                    }
                                        function epichargeInit(){
                                            var list = alist.split('|');
                                            sobj.length = 0;
                                            for(var i = 0; i < list.length-1; i++){
                                                oOption = document.createElement("OPTION");
                                                oOption.value = list[i];
                                                oOption.text = list[++i];
                                                sobj.add(oOption);
                                            }
                                     
                                        }
                                     </script>
                                </div>
<!--安排访谈时间-->
                                <div id="preInter" style="display: none">
                                   <div style="display: none">
                              		<input type="text" name="iyearp" id="iyearp" />
                                    <input type="text" name="imonthp" id="imonthp" />
                                    <input type="text" name="idayp" id="idayp" />
                                    </div>
                                    <div class="clearfix">

                                        <label for="year" class="form-label">Interview Time<em></em><small id="rolenote"></small></label>
    
                                        
                                        <select class="dateselect" id="yearp" name="yearp">                                    
                                        </select>
                                        年
    
                                        <select class="dateselect" id="monthp" name="monthp">                                    
                                        </select>
                                        月
                                        <select class="dateselect" id="dayp" name="dayp">                                    
                                        </select>
                                        日
                            

                                    </div>
                                    <p></p>
                                   
                              	    <script type="text/javascript">
                            	
                                    	initDate(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp"));  
                                    	document.getElementById("yearp").onchange = function(){resetDay(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp")); setIyearp();}
                                    	document.getElementById("monthp").onchange = function(){resetDay(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp")); setImonthp();}
                                    	document.getElementById("dayp").onchange = function(){setIdayp();}
                                     </script>
                                  </div>
   <!--已访谈-->                          
                             <div id="interviewInfo" style="display: none"> 
                                 <div style="display: none">
                          		<input type="text" name="iyear" id="iyear" />
                                <input type="text" name="imonth" id="imonth" />
                                <input type="text" name="iday" id="iday" />
                                </div>
                                <div class="clearfix">

                                        <label for="year" class="form-label">Interview Time<em></em><small id="rolenote"></small></label>
    
                                        
                                        <select class="dateselect" id="year" name="year">                                    
                                        </select>
                                        年
    
                                        <select class="dateselect" id="month" name="month">                                    
                                        </select>
                                        月
                                        <select class="dateselect" id="day" name="day">                                    
                                        </select>
                                        日
                            

                                    </div>
                                    <p></p>
                                
                      	    <script type="text/javascript">
                    	
                        	initDate(document.getElementById("year"), document.getElementById("month"), document.getElementById("day"));  
                        	document.getElementById("year").onchange = function(){resetDay(document.getElementById("year"), document.getElementById("month"), document.getElementById("day")); setIyear();}
                        	document.getElementById("month").onchange = function(){resetDay(document.getElementById("year"), document.getElementById("month"), document.getElementById("day")); setImonth();}
                        	document.getElementById("day").onchange = function(){setIday();}
                            </script>
                            <div class="clearfix">

                                    <label for="istime" class="form-label">Start from <em></em><small>格式为HH:MM，如08:01</small></label>

                                    <div class="form-input"><input type="text" id="istime" name="istime" /></div>

                            </div>  
                            
                            <div class="clearfix">

                                    <label for="ietime" class="form-label">To <em></em><small>格式为HH:MM，如08:01</small></label>

                                    <div class="form-input"><input type="text" id="ietime" name="ietime" /></div>

                            </div>
                            <div class="clearfix">

                                    <label for="iltime" class="form-label">Time Length <em></em><small>点击空白处自动计算</small></label>

                                    <div class="form-input"><input type="text" id="iltime" name="iltime" onclick="calculateTime()" /></div>

                            </div>
                            <div class="clearfix">

                                    <label for="ilhour" class="form-label">Charge Length <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="ilhour" name="ilhour" /></div>

                            </div> 
                            <div class="clearfix">

                                    <label for="ifee" class="form-label">Expense <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="ifee" name="ifee" /></div>

                            </div>         
                        </div>
<!--已评分!-->
                        <div id="interviewScore" style="display: none">
                            <div class="clearfix">

                                    <label for="iscorer" class="form-label">Rating Marker<em></em><small></small></label>
                                    <div class="form-input"><select id="iscorer" name="iscorer" >
                                    <option value="">请选择联系人</option>
                                    <?php
                                        if($contact_list){
                                            foreach($contact_list as $contacts){
                                    ?>
                              	        <option value="<?=$contacts?>"><?=$contacts?></option>
                           	        <?php
                                       }}
                                       else{
                                       ?>
                                            <option value="">请先关联客户</option>
                                    <?php
                                    }
                                    ?>
                                    </select></div>
                                    
                            </div>
                             
                             <div class="clearfix">

                                    <label for="score1" class="form-label">Expertise<em></em><small></small></label>

                                    <div class="form-input"><select id="score1" name="score1" >
                                        <option value="1">1分</option>
                              	        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                    </select></div>
                                    
                             </div>
                             <div class="clearfix">

                                    <label for="score2" class="form-label">Communication<em></em><small></small></label>

                                    <div class="form-input"><select id="score2" name="score2" >
                                        <option value="1">1分</option>
                              	        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                    </select></div>
                                    
                             </div>
                             <div class="clearfix">

                                    <label for="score3" class="form-label"> Drive and initiative<em></em><small></small></label>

                                    <div class="form-input"><select id="score3" name="score3" >
                                        <option value="1">1分</option>
                              	        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                    </select></div>
                                    
                             </div>
                             <div class="clearfix">

                                    <label for="ascore" class="form-label">Total Rating <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="ascore" name="ascore" onclick="calculateScore()"/></div>

                             </div>
                             </form>
                         </div>
                                    <div style="text-align: right;">

                                        <button  onclick="validate()">OK</button>


                                    </div>                         
                                </div> 
                            
                        </section>
                    </div>
                </section>
            </section>



   


	
          
          
          
          <script type="text/javascript">
		   
          function statusChange(){
			  div1 = document.getElementById("preInter");
			  div2 = document.getElementById("interviewInfo");
			  div3 = document.getElementById("interviewScore");
			  i = document.getElementById("estatus").value;
			  if(i == 4){
				  div1.style.display = "inline";
				  div2.style.display = "none";
				  div3.style.display = "none";
				  }
			  else if(i == 5){
				  div2.style.display = "inline";
				  div1.style.display = "none";
				  div3.style.display = "none";
				  }
			  else if(i == 6){
				  div3.style.display = "inline";
				  div2.style.display = "none";
				  div1.style.display = "none";
				  }
			  else {
				  div1.style.display = "none";
				  div2.style.display = "none";
				  div3.style.display = "none";
				  }
			  }
			  function setIyearp(){
					document.getElementById("iyearp").value = document.getElementById("yearp").value;
				//	alert("安排年" + document.getElementById("iyearp").value);
				}
				
				function setImonthp(){
					document.getElementById("imonthp").value = document.getElementById("monthp").value;
				//	alert(document.getElementById("imonthp").value);
				}
				
				function setIdayp(){
					document.getElementById("idayp").value = document.getElementById("dayp").value;
				//	alert(document.getElementById("idayp").value);
				}
				 function setIyear(){
					document.getElementById("iyear").value = document.getElementById("year").value;
				//	alert(document.getElementById("iyear").value);
				}
				
				function setImonth(){
					document.getElementById("imonth").value = document.getElementById("month").value;
					//alert(document.getElementById("imonth").value);
				}
				
				function setIday(){
					document.getElementById("iday").value = document.getElementById("day").value;
				//	alert(document.getElementById("iday").value);
				}
				function calculateTime(){
					s_time = document.getElementById("istime").value.split(':');
					e_time = document.getElementById("ietime").value.split(':');
					a_time = (Number(e_time[0]) - Number(s_time[0]))*60 + Number(e_time[1]) - Number(s_time[1]);
                    a_hour = Math.ceil(a_time/30)*Number(document.getElementById("halfhour").value);
					document.getElementById("iltime").value = a_time;
                    document.getElementById("ilhour").value = a_hour;
				}
				function calculateScore(){
					score_1 = document.getElementById("score1").value;
					score_2 = document.getElementById("score2").value;
					score_3 = document.getElementById("score3").value;
				    a_score = (Number(score_1) + Number(score_2) + Number(score_3));	
				//	a_score = a_score.toFixed(0);				
					document.getElementById("ascore").value = a_score;
				}
				
          </script>
<script type="text/javascript">
//主要是进行绑定，绑定时应该将当前以增加的行业顾问+1这样到最后判断的时候从数据库判断，不需要eneed，以为有可能加时分开家的，eneed没意义
 	function validate(){
            //isTime这个函数未定义
			//if(!isEmpty(document.getElementById("istime").value)) {if(!isTime(document.getElementById("istime").value)){alert("请按照格式填写开始时间"); document.getElementById("istime").focus(); return; }}
			//if(!isEmpty(document.getElementById("ietime").value)) {if(!isTime(document.getElementById("ietime").value)){alert("请按照格式填写结束时间"); document.getElementById("ietime").focus(); return; }}
			if(!isEmpty(document.getElementById("iltime").value) && (document.getElementById("iltime").value < 0)) {alert("结束时间要晚于开始时间"); document.getElementById("istime").focus(); return;}
			if(!isEmpty(document.getElementById("ifee").value)) {if(!isNumber(document.getElementById("ifee").value)){alert("访谈费用应为整数"); document.getElementById("ifee").focus(); return; }}
			//if(!isEmpty(document.getElementById("iscorer").value)) {if(!isName(document.getElementById("iscorer").value)){alert("评分人应为英文或中文"); document.getElementById("ifee").focus(); return; }}

			var choose=$('#estatus').attr('value');
			var eid=$('#eid').attr('value');
			var piid=$('#piid').attr('value');
            var epicharge = $('#epicharge').attr('value');
            //alert(epicharge);
			if((choose>=1 && choose<=3)|| choose==7)
			{
				var str="state="+choose+"&eid="+eid+"&piid="+piid + "&epicharge=" + epicharge;
			}else if(choose==4){
				var y=$('#iyearp').attr('value');
				var m=$('#imonthp').attr('value');
				var d=$('#idayp').attr('value');
				if(y==""){
					alert("请选择年份!");
					return;
				}
				if(m==""){
					alert("请选择月份！");
					return;
				}
				if(d==""){
					alert("请选择天数！");
					return;
				}
				var str="state=4&days="+y+'-'+m+'-'+d+"&eid="+eid+"&piid="+piid + "&epicharge=" + epicharge;
			}else if(choose==5){
				var y=$('#iyear').attr('value');
				var m=$('#imonth').attr('value');
				var d=$('#iday').attr('value');
				if(y==""){
					alert("请选择年份!");
					return;
				}
				if(m==""){
					alert("请选择月份！");
					return;
				}
				if(d==""){
					alert("请选择天数！");
					return;
				}
				var date=y+'-'+m+'-'+d+' ';
				var sdate=date+$('#istime').attr('value')+":00";
				var edate=date+$('#ietime').attr('value')+":00";
				var ltime=$('#iltime').attr('value');
				var cost=$('#ifee').attr('value');
                var ilhour=$('#ilhour').attr('value');
				var str="state=5&starttime="+sdate+"&endtime="+edate+"&totaltime="+ltime+"&ilhour="+ilhour+"&cost="+cost+"&eid="+eid+"&piid="+piid + "&epicharge=" + epicharge;
			}else if(choose==6){
				var scorer=$('#iscorer').attr('value');
				if(scorer==""){
					alert("评分人为空！");
						return;
					}
				var s1=$('#score1').attr('value');
				var s2=$('#score2').attr('value');
				var s3=$('#score3').attr('value');
				calculateScore();
				var avgs=$('#ascore').attr('value');
				var str="state=6&scorer="+scorer+"&s1="+s1+"&s2="+s2+"&s3="+s3+"&eid="+eid+"&piid="+piid+"&avgs="+avgs + "&epicharge=" + epicharge;
			}
			callAjaxBoundEP(str,piid);
	}
		
 </script>