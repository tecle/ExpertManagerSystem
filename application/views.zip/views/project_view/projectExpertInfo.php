   <section>
                <header class="container_12 clearfix">
                    <div class="grid_12">
                        <h1>Consultant Required</h1>
                    </div>
                </header>
                <a href="<?php echo $url['project'].'/addExpert/'.$piid.'/1/1'?>"><button>ADD</button></a>
                <a href="<?php echo $url['project'].'/showProjectInfo/'.$piid?>"><button>RETURN</button></a>
                <section class="container_12 clearfix">              
                    <input type="text" id="piid" name="piid" value='<?= $piid ?>' style="display: none;"/>
                    <input type="text" id="halfhour" name="halfhour" value="<?= $ghalfhour?>" style="display: none;"/>
                	<!--合作专家-->
             
                 <!--每个合作专家-->
	  
                    <script type="text/javascript">
                	  var eidUsing;
                      var pidUsing;
                        function basicChange(eid,pid,num){
                			eidUsing=eid;
                            pidUsing=pid;
                           	document.getElementById("basicDiv").style.display = "none";
                			document.getElementById("statusChange").style.display = "inline";
                            //初始化文本信息
                             document.getElementById("iltime").value = document.getElementById('init_tt'+num).value;
                             document.getElementById("ilhour").value = document.getElementById('init_il'+num).value;
                             document.getElementById("ifee").value = document.getElementById('init_cost'+num).value;
                             document.getElementById("ascore").value = document.getElementById('init_avgs'+num).value;
                             init_st = document.getElementById('init_st' + num).value;
                             init_et = document.getElementById('init_et' + num).value;
                           //初始化访谈时间
                             if(init_st){
                                document.getElementById("istime").value = init_st.split(' ')[1];
                             }
                             else{
                                document.getElementById("istime").value = '';
                             }
                             
                             if(init_et){
                                document.getElementById("ietime").value = init_et.split(' ')[1];
                             }
                             else{
                                document.getElementById("ietime").value = '';
                             }
                            //初始化访谈安排日期
                             init_itime = document.getElementById('init_itime' + num).value;
                             var init_iyear = 0;
                             var init_imonth = 0;
                             var init_iday = 0;
                             var init_eyear = 0;
                             var init_emonth = 0;
                             var init_eday = 0;
                             if(init_itime){
                                init_list = init_itime.split('-');
                                if(init_list.length == 3){
                                    init_iyear = init_list[0];
                                    init_imonth =init_list[1];
                                    init_iday = init_list[2];
                                }
                             }
                             initDate(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp"),init_iyear,init_imonth,init_iday);  
                             //初始化访谈日期
                             etime = '';
                             if(init_st)
                                etime = init_st.split(' ')[0];
                             if(etime){
                                if(etime != '至今'){
                                    elist = etime.split('-');
                                    if(elist.length==3){
                                        init_eyear = elist[0];
                                        init_emonth = elist[1];
                                        init_eday = elist[2];
                                    }
                                }
                             }
                             initDate(document.getElementById("year"), document.getElementById("month"), document.getElementById("day"),init_eyear,init_emonth,init_eday);  
                             //初始化评分人
                             
                             init_sr = document.getElementById('init_sr' + num).value;
                            // alert(init_sr);
                            
                             var inits = new Array();
                             inits[1] = document.getElementById('init_s1' + num).value;
                             inits[2] = document.getElementById('init_s2' + num).value;
                             inits[3] = document.getElementById('init_s3' + num).value;
                             for(var scorei=1; scorei<=3; scorei++){
                                score_obj = document.getElementById('score'+scorei);
                                score_obj.length = 0;
                                for(var optioni=1; optioni<=3; optioni++){
                                    oOption = document.createElement("OPTION");
                                    oOption.value = optioni;
                                    oOption.text = optioni+'分';
                                    if(inits[scorei] == optioni)
                                        oOption.selected = true;
                                    score_obj.add(oOption);
                                }
                             }
                             init_wname = document.getElementById('init_wname'+ num).value;
                             epichargeInit(init_wname);
                             init_state = document.getElementById('init_stat'+ num).value;
                             istobj = document.getElementById('estatus');
                             istobj.length = 0;
                             oOption = document.createElement("OPTION");
                             oOption.value = 1;
                             oOption.text = '聘用';
                             if(init_state == 1)
                                oOption.selected = true;
                             istobj.add(oOption);
                              oOption = document.createElement("OPTION");
                             oOption.value = 2;
                             oOption.text = '合作';
                             if(init_state == 2)
                                oOption.selected = true;
                             istobj.add(oOption);
                              oOption = document.createElement("OPTION");
                             oOption.value = 3;
                             oOption.text = '推荐';
                             if(init_state == 3)
                                oOption.selected = true;
                             istobj.add(oOption);
                              oOption = document.createElement("OPTION");
                             oOption.value = 4;
                             oOption.text = '已预约';
                             if(init_state == 4)
                                oOption.selected = true;
                             istobj.add(oOption); oOption = document.createElement("OPTION");
                             oOption.value = 5;
                             oOption.text = '已访谈';
                             if(init_state == 5)
                                oOption.selected = true;
                             istobj.add(oOption); oOption = document.createElement("OPTION");
                             oOption.value = 6;
                             oOption.text = '已评分';
                             if(init_state == 6)
                                oOption.selected = true;
                             istobj.add(oOption);
                              oOption = document.createElement("OPTION");
                             oOption.value = 7;
                             oOption.text = '已付款';
                             if(init_state == 7)
                                oOption.selected = true;
                             istobj.add(oOption);
                             statusChange();
                              	       // <option value="1">聘用</option>
//                              	        <option value="2">合作</option>
//                                        <option value="3">推荐</option>
//                                        <option value="4">已预约</option>
//                                        <option value="5">已访谈</option>
//                                        <option value="6">已评分</option>
//                                        <option value="7">已付款</option>
                             
			         }
                 	    function basicUnchange(){
                        	document.getElementById("basicDiv").style.display = "inline";
                        	document.getElementById("statusChange").style.display = "none";
                        	}
                    </script>
                    <?php
                        if(!empty($experts)){
                        ?>
                    <section class="portlet grid_12 leading">
                         <header>
                            <h2>Consultants</h2>
                        </header>
                        <section id="consultants" >
                        
                        <div  id="basicDiv">
                        <?php
                            $p = 1;
                             foreach($experts as $row){
                			     switch($row['state']){
                					case '1':
                						$ste='聘用';
                						$style=1;
                						break;
                					case '2':
                						$ste='合作';
                						$style=1;
                						break;
                					case '3':
                						$ste='推荐';
                						$style=1;
                						break;
                					case '4':
                						$ste='已预约';
                						$style=2;
                						break;
                					case '5':
                						$ste='已访谈';
                						$style=3;
                						break;
                					case '6':
                						$ste='已评分';
                						$style=4;
                						break;
                					case '7':
                						$ste='已付款';
                						$style=4;
                						break;
                					default:
                						$ste='未知';
                						$style=0;
                						break;
                				}
                                $ename=$row['ename'];
                                $wname=$row['wname'];
                				$itime=$row['itime'];
                				$st=$row['starttime'];
                				$et=$row['endtime'];
                				$tt=$row['totaltime'];
                                $il=$row['ilhour'];
                				$cost=$row['cost'];
                				$sr=$row['scorer'];
                				$s1=$row['s1'];
                				$s2=$row['s2'];
                				$s3=$row['s3'];
                				$avgs=$row['avgs'];
                				$eid=$row['eid'];
                                
                        ?>
                            <section class="clearfix">
                                <div style="display: none;">
                                    <input type="text" id="init_stat<?=$p?>" value="<?=$row['state']?>" />
                                    <input type="text" id="init_wname<?=$p?>" value="<?=$wname?>" />
                                    <input type="text" id="init_itime<?=$p?>" value="<?=$itime?>" />
                                    <input type="text" id="init_st<?=$p?>" value="<?=$st?>" />
                                    <input type="text" id="init_et<?=$p?>" value="<?=$et?>" />
                                    <input type="text" id="init_tt<?=$p?>" value="<?=$tt?>" />
                                    <input type="text" id="init_il<?=$p?>" value="<?=$il?>" />
                                    <input type="text" id="init_cost<?=$p?>" value="<?=$cost?>" />
                                    <input type="text" id="init_sr<?=$p?>" value="<?=$sr?>" />
                                    <input type="text" id="init_s1<?=$p?>" value="<?=$s1?>" />
                                    <input type="text" id="init_s2<?=$p?>" value="<?=$s2?>" />
                                    <input type="text" id="init_s3<?=$p?>" value="<?=$s3?>" />
                                    <input type="text" id="init_avgs<?=$p?>" value="<?=$avgs?>" />                                    
                                </div>
                                <table id="workul" class="display" width="100%">
                                    <tbody>
                                    <tr>
                                     <td colspan="2"><h2>Consultants <?=$p?></h2></td>
                                    <td colspan="2" ><div class="form-action clearfix" style="text-align: right;">

                                    <button class="button"  onclick="basicChange(<?=$eid?>,<?=$piid?>,<?=$p?>)" data-icon-primary="ui-icon-circle-check">Modify</button>

                                    </div></td>
                                    </tr>

                                    <tr class="gradeA">
                                    <th width="18%">Consultant Name：</th>
                                    <td id="sename" width="32%"><a href="<?= $url['expert']?>/showExpertInfo/<?=$eid?>"><?=$ename?></a></td>
                                    <th width="15%">Status：</th>
                                    <td width="35%" id="sestatus"><?=$ste?></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>PIC：</th>
                                    <td><?=$wname ?></td>
                                    <td><td></td></td>
                                    </tr>
                            		<?php 
                            		if($style==1){
                            	  ?>
                            	  <?php
                            		}else if($style==2){
                            		?>	
                       	            <tr class="gradeA">
                                    <th> Interview Time：</th>
                                    <td id="idatep"><?=$itime?></td>
                                    <td></td><td></td>
                                    </tr>
                            		<?php
                            		}else if($style==3){
                            		?>
            	                    <tr class="gradeA">
                                    <th> Interview Time：</th>
                                    <td ><?=$itime?></td>
                                    <td><td></td></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th width="18%">Start from：</th>
                                    <td width="32%"><?=$st?></td>
                                    <th width="15%"> To：</th>
                                    <td width="35%"><?=$et?></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>Time Length（min）：</th>
                                    <td><?=$tt?></td>
                                    <th> Expense：</th>
                                    <td><?=$cost?></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>Charge Length(h):</th>
                                    <td><?=$il?></td>
                                    <td><td></td></td>
                                    </tr>
                            		<?php
                            	  }else if($style==4){
                            		?>
                       	            <tr class="gradeA">
                                    <th>Interview Time：</th>
                                    <td><?=$itime?></td>
                                    <td><td></td></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th width="18%">Start from：</th>
                                    <td width="32%"><?=$st?></td>
                                    <th width="15%">To：</th>
                                    <td width="35%"><?=$et?></td>                                    
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>Time Length（min）：</th>
                                    <td><?=$tt?></td>
                                    <th>Expense：</th>
                                    <td><?=$cost?></td></tr>
                                    
                                    <tr class="gradeA">
                                    <th>Charge Length(h):</th>
                                    <td><?=$il?></td>
                                    <td><td></td></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>Rating Marker：</th>
                                    <td><?=$sr?></td>  
                                    <td><td></td></td>                                  
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>Expertise：</th>
                                    <td><?=$s1?></td>
                                    <th>Communication：</th>
                                    <td ><?=$s2?></td>
                                    </tr>
                                    
                                    <tr class="gradeA">
                                    <th>Drive and initiative：</th>
                                    <td><?=$s3?></td>
                                    <th>Total Rating：</th>
                                    <td ><?=$avgs?></td>
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </section>
                    <?php
                    $p++;
                            }                                              
                        ?>
                        </div>
                        <div  id="statusChange" style="display: none">
                        <section>
                        <div style="display: none">
                        	<input type="text" id="eid" name="eid" />
                        </div>
                        <form class="form">
                       <div class="clearfix">
                                    <label for="estatus" class="form-label">Status<em></em><small id="rolenote"></small></label>
                              	      <div class="form-input"><select name="estatus" id="estatus" onchange="statusChange()">
                              	        <option value="1">聘用</option>
                              	        <option value="2">合作</option>
                                        <option value="3">推荐</option>
                                        <option value="4">已预约</option>
                                        <option value="5">已访谈</option>
                                        <option value="6">已评分</option>
                                        <option value="7">已付款</option>
                                      </select></div>
                                </div>
                                <div class="clearfix">

                                    <label for="epicharge" class="form-label">PIC<em>*</em><small></small></label>

                                    <div class="form-input"><select id="epicharge" name="epicharge" onchange="statusChange()">
                                    </select></div>
                                        <script>//获取admin列表
                                        var sobj = document.getElementById("epicharge");
                                        var alist;
                                        getAdminList('type=6');
                                        function getAdminList(string){
                                        $.ajax({
                                                    type: 'post',
                                                    //可选get
                                                    url: '/CIFramework/index.php/project/welcome/projectAjax',
                                                    //这里是接收数据的PHP程序
                                                    data: string,
                                                    //传给PHP的数据，多个参数用&连接
                                                    dataType: 'text',
                                                    //服务器返回的数据类型 可选XML ,Json jsonp script html text等
                                                    success: function(msg) {
                                                           // return msg;
                                                            alist = msg;
                                                            epichargeInit();
                                                            //这里是ajax提交成功后，PHP程序返回的数据处理函数。msg是返回的数据，数据类型在dataType参数里定义！
                                                    },
                                                    error: function() {
                                                            alert("获取用户列表失败!");
                                                    }
                                            })
                                    }
                                        function epichargeInit(name){
                                            var list = alist.split('|');
                                            sobj.length = 0;
                                            for(var i = 0; i < list.length-1; i++){
                                                oOption = document.createElement("OPTION");
                                                oOption.value = list[i];
                                                oOption.text = list[++i];
                                                if(name == list[i])
                                                    oOption.selected = true;
                                                sobj.add(oOption);
                                            }
                                     
                                        }
                                     </script>
                                </div>
<!--安排访谈时间-->
                                
                                <div id="preInter" style="display: none">
                                   <div style="display: none">
                              		<input type="text" name="iyearp" id="iyearp" />
                                    <input type="text" name="imonthp" id="imonthp" />
                                    <input type="text" name="idayp" id="idayp" />
                                    </div>
                                    <div class="clearfix">

                                        <label for="year" class="form-label">Interview Time<em></em><small id="rolenote"></small></label>
    
                                        
                                        <select class="dateselect" id="yearp" name="yearp">                                    
                                        </select>
                                        年
    
                                        <select class="dateselect" id="monthp" name="monthp">                                    
                                        </select>
                                        月
                                        <select class="dateselect" id="dayp" name="dayp">                                    
                                        </select>
                                        日
                            

                                    </div>
                                    <p></p>
                                   
                              	    <script type="text/javascript">
                            	
                                    	initDate(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp"));  
                                    	document.getElementById("yearp").onchange = function(){resetDay(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp")); setIyearp();}
                                    	document.getElementById("monthp").onchange = function(){resetDay(document.getElementById("yearp"), document.getElementById("monthp"), document.getElementById("dayp")); setImonthp();}
                                    	document.getElementById("dayp").onchange = function(){setIdayp();}
                                     </script>
                                  </div>
   <!--已访谈-->                          
                             <div id="interviewInfo" style="display: none"> 
                                 <div style="display: none">
                          		<input type="text" name="iyear" id="iyear" />
                                <input type="text" name="imonth" id="imonth" />
                                <input type="text" name="iday" id="iday" />
                                </div>
                                <div class="clearfix">

                                        <label for="year" class="form-label">Interview Time<em></em><small id="rolenote"></small></label>
    
                                        
                                        <select class="dateselect" id="year" name="year">                                    
                                        </select>
                                        年
    
                                        <select class="dateselect" id="month" name="month">                                    
                                        </select>
                                        月
                                        <select class="dateselect" id="day" name="day">                                    
                                        </select>
                                        日
                            

                                    </div>
                                    <p></p>
                                
                      	    <script type="text/javascript">
                    	
                        	initDate(document.getElementById("year"), document.getElementById("month"), document.getElementById("day"));  
                        	document.getElementById("year").onchange = function(){resetDay(document.getElementById("year"), document.getElementById("month"), document.getElementById("day")); setIyear();}
                        	document.getElementById("month").onchange = function(){resetDay(document.getElementById("year"), document.getElementById("month"), document.getElementById("day")); setImonth();}
                        	document.getElementById("day").onchange = function(){setIday();}
                            </script>
                            
                            <div class="clearfix">

                                    <label for="istime" class="form-label">Start from <em></em><small>格式为HH:MM，如08:01</small></label>

                                    <div class="form-input"><input type="text" id="istime" name="istime" /></div>

                            </div>  
                            <div class="clearfix">

                                    <label for="ietime" class="form-label">To <em></em><small>格式为HH:MM，如08:01</small></label>

                                    <div class="form-input"><input type="text" id="ietime" name="ietime" /></div>

                            </div>
                            <div class="clearfix">

                                    <label for="iltime" class="form-label">Time Length <em></em><small>点击空白处自动计算</small></label>

                                    <div class="form-input"><input type="text" id="iltime" name="iltime" onclick="calculateTime()" /></div>

                            </div>
                            <div class="clearfix">

                                    <label for="ilhour" class="form-label">Charge Length <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="ilhour" name="ilhour" /></div>

                            </div> 

                            <div class="clearfix">

                                    <label for="ifee" class="form-label">Expense <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="ifee" name="ifee" /></div>

                            </div>  
                       
                        </div>
<!--已评分!-->
                        <div id="interviewScore" style="display: none">
                            <div class="clearfix">

                                    <label for="iscorer" class="form-label">Rating Marker<em></em><small></small></label>

                                    <div class="form-input"><select id="iscorer" name="iscorer" >
                                    <option value="">请选择联系人</option>
                                    <?php
                                        if($contact_list){
                                            foreach($contact_list as $contacts){
                                    ?>
                              	        <option value="<?=$contacts?>"><?=$contacts?></option>
                           	        <?php
                                       }}
                                       else{
                                       ?>
                                            <option value="">请先关联客户</option>
                                    <?php
                                    }
                                    ?>
                                    </select></div>
                                    
                            </div>
                             
                             <div class="clearfix">

                                    <label for="score1" class="form-label">Expertise<em></em><small></small></label>

                                    <div class="form-input"><select id="score1" name="score1" >
                                        <option value="1">1分</option>
                              	        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                    </select></div>
                                    
                             </div>
                             <div class="clearfix">

                                    <label for="score2" class="form-label">Communication<em></em><small></small></label>

                                    <div class="form-input"><select id="score2" name="score2" >
                                        <option value="1">1分</option>
                              	        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                    </select></div>
                                    
                             </div>
                             <div class="clearfix">

                                    <label for="score3" class="form-label"> Drive and initiative<em></em><small></small></label>

                                    <div class="form-input"><select id="score3" name="score3" >
                                        <option value="1">1分</option>
                              	        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                    </select></div>
                                    
                             </div>

                             <div class="clearfix">

                                    <label for="ascore" class="form-label">Total Rating <em></em><small></small></label>

                                    <div class="form-input"><input type="text" id="ascore" name="ascore" onclick="calculateScore()"/></div>

                             </div>
                             </form>
                            </div>
                                <div  style="text-align: right;">

                                    <button   onclick="validate()">OK</button>

                                    <button  onclick="basicUnchange()">Cancel</button>

                                </div>
                            	
                        </section>
                        </div>
                        </section>
                      	
                    </section>
                     <?php
                    }                                           
                        ?> 
        
      <!--所需专家结束-->
                    
                    
            </section>
            </section>
    
          <script type="text/javascript">
		  
          function statusChange(){
			  div1 = document.getElementById("preInter");
			  div2 = document.getElementById("interviewInfo");
			  div3 = document.getElementById("interviewScore");
			  i = document.getElementById("estatus").value;
			  if(i == 4){
				  div1.style.display = "inline";
				  div2.style.display = "none";
				  div3.style.display = "none";
				  }
			  else if(i == 5){
				  div2.style.display = "inline";
				  div1.style.display = "none";
				  div3.style.display = "none";
				  }
			  else if(i == 6){
				  div3.style.display = "inline";
				  div2.style.display = "none";
				  div1.style.display = "none";
				  }
			  else {
				  div1.style.display = "none";
				  div2.style.display = "none";
				  div3.style.display = "none";
				  }
			  }
			  function setIyearp(){
					document.getElementById("iyearp").value = document.getElementById("yearp").value;
				//	alert("安排年" + document.getElementById("iyearp").value);
				}
				
				function setImonthp(){
					document.getElementById("imonthp").value = document.getElementById("monthp").value;
				//	alert(document.getElementById("imonthp").value);
				}
				
				function setIdayp(){
					document.getElementById("idayp").value = document.getElementById("dayp").value;
				//	alert(document.getElementById("idayp").value);
				}
				 function setIyear(){
					document.getElementById("iyear").value = document.getElementById("year").value;
				//	alert(document.getElementById("iyear").value);
				}
				
				function setImonth(){
					document.getElementById("imonth").value = document.getElementById("month").value;
					//alert(document.getElementById("imonth").value);
				}
				
				function setIday(){
					document.getElementById("iday").value = document.getElementById("day").value;
				//	alert(document.getElementById("iday").value);
				}
				function calculateTime(){
					s_time = document.getElementById("istime").value.split(':');
					e_time = document.getElementById("ietime").value.split(':');
					a_time = (Number(e_time[0]) - Number(s_time[0]))*60 + Number(e_time[1]) - Number(s_time[1]);
                    a_hour = Math.ceil(a_time/30)*Number(document.getElementById("halfhour").value);
					document.getElementById("iltime").value = a_time;
                    document.getElementById("ilhour").value = a_hour;
				}
				function calculateScore(){
					score_1 = document.getElementById("score1").value;
					score_2 = document.getElementById("score2").value;
					score_3 = document.getElementById("score3").value;
				    a_score = (Number(score_1) + Number(score_2) + Number(score_3));		
					document.getElementById("ascore").value = a_score;
				}
				function basicSubmit(){
					document.form1.submit();
					}
          </script>
	    
	    <script type="text/javascript">
 	function validate(){
			var choose=$('#estatus').attr('value');
			var eid=eidUsing;
			var piid=pidUsing;
            var epicharge = $('#epicharge').attr('value');

			if((choose>=1 && choose<=3)|| choose==7)
			{
				var str="state="+choose+"&eid="+eid+"&piid="+piid + "&epicharge=" + epicharge;
			}else if(choose==4){
				var y=$('#iyearp').attr('value');
				var m=$('#imonthp').attr('value');
				var d=$('#idayp').attr('value');
				if(y==""){
					alert("请选择年份!");
					return;
				}
				if(m==""){
					alert("请选择月份！");
					return;
				}
				if(d==""){
					alert("请选择天数！");
					return;
				}
				var str="state=4&days="+y+'-'+m+'-'+d+"&eid="+eid+"&piid="+piid + "&epicharge=" + epicharge;
			}else if(choose==5){
				var y=$('#iyear').attr('value');
				var m=$('#imonth').attr('value');
				var d=$('#iday').attr('value');
				if(y==""){
					alert("请选择年份!");
					return;
				}
				if(m==""){
					alert("请选择月份！");
					return;
				}
				if(d==""){
					alert("请选择天数！");
					return;
				}
				var date=y+'-'+m+'-'+d+' ';
				var sdate=date+$('#istime').attr('value')+":00";
				var edate=date+$('#ietime').attr('value')+":00";
				var ltime=$('#iltime').attr('value');
				var cost=$('#ifee').attr('value');
                var ilhour=$('#ilhour').attr('value');
				var str="state=5&starttime="+sdate+"&endtime="+edate+"&totaltime="+ltime+"&ilhour="+ilhour+"&cost="+cost+"&eid="+eid+"&piid="+piid + "&epicharge=" + epicharge;
			}else if(choose==6){
				var scorer=$('#iscorer').attr('value');
				if(scorer==""){
					alert("评分人为空！");
						return;
					}
				var s1=$('#score1').attr('value');
				var s2=$('#score2').attr('value');
				var s3=$('#score3').attr('value');
				calculateScore();
				var avgs=$('#ascore').attr('value');
				var str="state=6&scorer="+scorer+"&s1="+s1+"&s2="+s2+"&s3="+s3+"&eid="+eid+"&piid="+piid+"&avgs="+avgs + "&epicharge=" + epicharge;
			}
            //alert(str);
			callAjaxAlterEP(str);
	}
		
 </script>

       
   