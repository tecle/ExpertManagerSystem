 <div class="clear"></div>	
    
    <div class="clear"></div>
 </div>
  <div class="bottom">  </div>
</div>

</body>
</html>