<?php
        echo '<script type="text/javascript">';
		echo 'top.location = "/CIFramework/index.php";';
		echo '</script>';
?>